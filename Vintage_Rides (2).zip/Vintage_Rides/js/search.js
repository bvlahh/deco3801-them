$('#20s').click(function() {
    $('.20s').show(500);
    $('.30s').hide(500);
    $('.40s').hide(500);
    $('.50s').hide(500);
    $('.60s').hide(500);
    $('.70s').hide(500);
});
$('#30s').click(function() {
    $('.20s').hide(500);
    $('.30s').show(500);
    $('.40s').hide(500);
    $('.50s').hide(500);
    $('.60s').hide(500);
    $('.70s').hide(500);
});
$('#40s').click(function() {
    $('.20s').hide(500);
    $('.30s').hide(500);
    $('.40s').show(500);
    $('.50s').hide(500);
    $('.60s').hide(500);
    $('.70s').hide(500);
});
$('#50s').click(function() {
   	$('.20s').hide(500);
    $('.30s').hide(500);
    $('.40s').hide(500);
    $('.50s').show(500);
    $('.60s').hide(500);
    $('.70s').hide(500);
});
$('#60s').click(function() {
    $('.20s').hide(500);
    $('.30s').hide(500);
    $('.40s').hide(500);
    $('.50s').hide(500);
    $('.60s').show(500);
    $('.70s').hide(500);
});
$('#70s').click(function() {
   	$('.20s').hide(500);
    $('.30s').hide(500);
    $('.40s').hide(500);
    $('.50s').hide(500);
    $('.60s').hide(500);
    $('.70s').show(500);
});

$('#showall').click(function() {
    $('.post').show(500);
});