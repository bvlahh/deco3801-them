#!/bin/bash

echo "call garbage_collect();" | mysql -t -D validator;

